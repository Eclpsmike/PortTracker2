# Facility Floor Plan Editor — Codex handoff

This package is a **specification and reference starter**, not a finished application.

1. Open this folder in VS Code with Codex.
2. Tell Codex: **Read CODEX_START_HERE.md. Implement the complete runnable Phase 1 example page first, matching the provided visual references. Do not build backend/APK/sync yet.**
3. Use `examples/sample-floorplan.svg` as the bundled first-load plan.
4. Use `examples/sample-project.json` as sample metadata and exercise the workflow.
5. Review `docs/PRODUCT_REQUIREMENTS.md` for object relationships and later-phase boundaries.

Visual reference images in the conversation show the desired navy-header, light-panel, central floor-plan canvas, left drawing tools and right layers/filters/properties. Recreate with real interactive objects, not a screenshot as the canvas.
