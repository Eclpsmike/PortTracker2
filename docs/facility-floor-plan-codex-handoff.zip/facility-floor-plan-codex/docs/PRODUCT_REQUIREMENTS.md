# Facility Floor Plan Editor — Product Requirements

## Context
Standalone Network Cabinet Manager, visually consistent with approved navy/white rack manager UI. User uploads floor plan; places network endpoints even when cable paths are unknown. User draws named rectangular locations and manages visibility via right-side layers and filters. UI-first, mock/local data initially.

## Data entities
- Project: id, schemaVersion, building, floors, timestamps, units.
- Floor: id, name, background asset and intrinsic dimensions, calibration, viewport.
- Location: id, floorId, name, type, rectangular geometry (x,y,width,height), color, notes, layerId.
- Layer: id, name, visible, locked, order, color, optional category.
- Endpoint/device: id, floorId, type, position, rotation, locationId?, layerId, metadata.
- Wall plate: id, floorId, position, portCount, stable port IDs, layerId, locationId?.
- Port: id, label, medium, mappingStatus, idfId?, patchPanelPortId?, switchPortId?, vlanId?, notes.
- Route: id, floorId, kind (cable/tray/conduit), point array, layerId, status, sourceId?, destinationId?, length metadata.
- Calibration: two plan-coordinate points, known distance, unit, computed units-per-plan-unit.

## Interaction model
Explicit tool state: select, pan, rectangle, marker, polyline, measure. Pointer events with mouse and touch. Selection should be reversible, overlays hit-test correctly, and zoom should not change stored geometry. Preserve original floor plan unchanged.

## Layers vs filters
Layer: user-controlled rendering and edit lock, custom grouping, independent from object status. Filter: derived visibility by metadata (type, status, room, VLAN, IDF). Hidden or filtered objects remain in project data and export.

## Later-phase backlog (not phase 1)
- QR/barcode labeling; photos, test results and certification records.
- Floor-plan revision management and migration of markers to new background.
- Automated room containment/room association suggestions.
- Bulk import of ports, automatic sequential numbering, duplicate/copy-paste.
- End-to-end jack→horizontal cable→patch panel→switch→VLAN trace.
- Cable tray capacity, risers between floors, route optimization and measured installed lengths.
- Android Capacitor shell, offline-first durable queue and conflict resolution.
- Backend, PostgreSQL, roles, auditing and deployment.

## Open choices that do not block first page
Naming conventions, final device taxonomy, which floor-plan file formats to prioritize for production, exact cable colors, and future API integration. Provide editable defaults rather than hardcoding assumptions.
